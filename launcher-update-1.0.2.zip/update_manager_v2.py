"""GTA VI personal launcher updater (v2): SHA-256 verification, retries and rollback.

This code updates only this launcher, not the GTA VI game or PS5 software.
"""
import hashlib, json, os, queue, re, shutil, subprocess, sys, tempfile, threading, time, urllib.error, urllib.request, zipfile
from pathlib import Path, PurePosixPath
import tkinter as tk
from tkinter import ttk

BASE = Path(__file__).resolve().parent
CONFIG = BASE / 'update_config.json'
STATE = BASE / 'update_version.json'
ALLOWED_SUFFIXES = {'.py', '.pyw', '.ico', '.dat', '.wav', '.mp3', '.png', '.jpg', '.jpeg', '.txt', '.json', '.cmd'}
PROTECTED = {'update_config.json', 'update_version.json'}
MAX_DOWNLOAD = 80 * 1024 * 1024
MAX_EXPANDED = 150 * 1024 * 1024
MAX_FILES = 40
USER_AGENT = 'GTAVI-Personal-Launcher-Updater/2.0'

def read_json(path, fallback):
    try:
        obj = json.loads(path.read_text(encoding='utf-8'))
        return obj if isinstance(obj, dict) else fallback
    except (OSError, ValueError):
        return fallback

def parse_version(value):
    value = str(value)
    if not re.fullmatch(r'\d+(?:\.\d+){0,3}', value):
        raise ValueError('Unsupported update version: ' + value)
    return tuple(int(x) for x in value.split('.')) + (0,) * (4 - len(value.split('.')))

def https_url(url):
    if not isinstance(url, str) or not url.startswith('https://'):
        raise ValueError('Update address must use HTTPS')
    # A public repository can serve launcher updates without GitHub API credentials.
    if not url.startswith('https://raw.githubusercontent.com/jaydenxrivera2015/GTAVI-LAUCHER-UPDATES/'):
        raise ValueError('Update URL is outside the configured GitHub repository')
    return url

def request(url):
    return urllib.request.Request(https_url(url), headers={'User-Agent': USER_AGENT, 'Cache-Control': 'no-cache'})

def fetch_json(url):
    last = None
    for attempt in range(3):
        try:
            with urllib.request.urlopen(request(url), timeout=12) as response:
                raw = response.read(65537)
            if len(raw) > 65536:
                raise ValueError('Update manifest is too large')
            manifest = json.loads(raw.decode('utf-8-sig'))
            if not isinstance(manifest, dict):
                raise ValueError('Invalid update manifest')
            return manifest
        except (OSError, ValueError, urllib.error.URLError) as exc:
            last = exc
            if attempt < 2:
                time.sleep(0.7 * (attempt + 1))
    raise RuntimeError('Unable to check for updates: ' + str(last))

def download(url, target, events):
    for attempt in range(3):
        try:
            h = hashlib.sha256()
            amount = 0
            with urllib.request.urlopen(request(url), timeout=25) as response, open(target, 'wb') as out:
                size = int(response.headers.get('Content-Length') or 0)
                if size > MAX_DOWNLOAD:
                    raise ValueError('Update exceeds safe download limit')
                while True:
                    chunk = response.read(128 * 1024)
                    if not chunk:
                        break
                    amount += len(chunk)
                    if amount > MAX_DOWNLOAD:
                        raise ValueError('Update exceeds safe download limit')
                    h.update(chunk)
                    out.write(chunk)
                    if size:
                        events.put(('progress', min(99, int(amount * 100 / size))))
            return h.hexdigest()
        except (OSError, urllib.error.URLError):
            if attempt == 2:
                raise
            events.put(('status', f'DOWNLOAD INTERRUPTED — RETRY {attempt + 1}/2'))
            time.sleep(1.0 * (attempt + 1))
    raise RuntimeError('Download did not complete')

def inspect_archive(path):
    with zipfile.ZipFile(path) as archive:
        entries = [i for i in archive.infolist() if not i.is_dir()]
        if not entries or len(entries) > MAX_FILES:
            raise ValueError('Invalid number of update files')
        if sum(i.file_size for i in entries) > MAX_EXPANDED:
            raise ValueError('Update expands beyond safe limit')
        existing = set()
        for info in entries:
            p = PurePosixPath(info.filename)
            if len(p.parts) != 1 or p.name != info.filename or '\\' in info.filename or ':' in info.filename:
                raise ValueError('Unsupported update path: ' + info.filename)
            name = p.name.casefold()
            if name in existing or name in PROTECTED or p.suffix.lower() not in ALLOWED_SUFFIXES:
                raise ValueError('Unsupported update entry: ' + info.filename)
            if info.external_attr >> 16 & 0o170000 == 0o120000:
                raise ValueError('Symbolic links are not permitted in updates')
            existing.add(name)
        broken = archive.testzip()
        if broken:
            raise ValueError('ZIP integrity check failed: ' + broken)
        return entries

def apply_update(archive_path, new_version):
    entries = inspect_archive(archive_path)
    backup = Path(tempfile.mkdtemp(prefix='.gtavi-backup-', dir=str(BASE)))
    staged = Path(tempfile.mkdtemp(prefix='.gtavi-stage-', dir=str(BASE)))
    committed = []
    try:
        with zipfile.ZipFile(archive_path) as archive:
            for item in entries:
                (staged / item.filename).write_bytes(archive.read(item))
        for item in entries:
            target = BASE / item.filename
            archived = backup / item.filename
            if target.exists():
                shutil.copy2(target, archived)
            os.replace(staged / item.filename, target)
            committed.append((target, archived))
        # Record the version last. If anything fails, existing code is restored.
        state_stage = staged / 'update_version.json'
        state_stage.write_text(json.dumps({'version': new_version}), encoding='utf-8')
        os.replace(state_stage, STATE)
        return backup
    except Exception:
        for target, archived in reversed(committed):
            try:
                if archived.exists():
                    shutil.copy2(archived, target)
                else:
                    target.unlink(missing_ok=True)
            except OSError:
                pass
        raise
    finally:
        shutil.rmtree(staged, ignore_errors=True)

def startup(root, playbtn, status):
    config = read_json(CONFIG, {})
    url = config.get('manifest_url', '')
    if not url:
        status.set('UPDATE CONFIGURATION MISSING')
        return
    events = queue.Queue()
    busy = {'value': True}
    progress = ttk.Progressbar(root, maximum=100, mode='determinate')
    progress.place(relx=.25, rely=.96, relwidth=.65)
    playbtn.configure(state='disabled')
    status.set('CHECKING FOR UPDATES')

    def worker():
        try:
            manifest = fetch_json(url)
            ver = manifest.get('version', '')
            candidate = parse_version(ver)
            present = parse_version(read_json(STATE, {'version': '0'}).get('version', '0'))
            if candidate <= present:
                events.put(('ready', 'Up to date'))
                return
            expected = manifest.get('sha256', '').lower()
            if not isinstance(expected, str) or not re.fullmatch(r'[a-f0-9]{64}', expected):
                raise ValueError('Update checksum is missing or invalid')
            events.put(('status', f'UPDATE {ver} — DOWNLOADING'))
            with tempfile.TemporaryDirectory(prefix='gtavi-update-') as folder:
                update_file = Path(folder) / 'update.zip'
                digest = download(manifest.get('url'), update_file, events)
                if digest != expected:
                    raise ValueError('Update verification failed (SHA-256 mismatch)')
                events.put(('status', 'INSTALLING VERIFIED UPDATE'))
                apply_update(update_file, ver)
            events.put(('restart', 'Update installed'))
        except Exception as err:
            events.put(('error', str(err)))

    def restart_launcher():
        try:
            subprocess.Popen([sys.executable, str(BASE / 'launcher.pyw')], cwd=str(BASE), close_fds=True)
        except OSError as err:
            status.set('UPDATE INSTALLED — RESTART MANUALLY: ' + str(err))
            playbtn.configure(state='normal')
            progress.destroy()
            return
        try:
            root.destroy()
        except tk.TclError:
            pass

    def poll():
        try:
            while True:
                kind, value = events.get_nowait()
                if kind == 'progress':
                    progress['value'] = value
                elif kind == 'status':
                    status.set(value)
                elif kind == 'restart':
                    restart_launcher()
                    return
                elif kind == 'ready':
                    status.set(value)
                    playbtn.configure(state='normal')
                    progress.destroy()
                    return
                elif kind == 'error':
                    # An offline PC can still play; update errors remain visible.
                    status.set('UPDATE CHECK FAILED — ' + value)
                    playbtn.configure(state='normal')
                    progress.destroy()
                    return
        except queue.Empty:
            try:
                root.after(100, poll)
            except tk.TclError:
                pass
    threading.Thread(target=worker, daemon=True).start()
    poll()
