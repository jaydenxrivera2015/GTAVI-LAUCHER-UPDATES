import tkinter as tk
from tkinter import filedialog,messagebox,simpledialog
from PIL import Image, ImageTk, ImageOps, ImageDraw
from pathlib import Path
import os,json,subprocess,sys,ctypes,webbrowser,shutil,threading,queue,time,uuid
from ctypes import wintypes
BASE=Path(__file__).resolve().parent
CFG=Path(os.environ['LOCALAPPDATA'])/'GTAVI_AstraWrapper'/'settings.json'
try: cfg=json.loads(CFG.read_text())
except (OSError,ValueError): cfg={}
ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID('Personal.GTAVI.Launcher')
root=tk.Tk(); root.title('Grand Theft Auto VI PC Dev Build'); root.geometry('1280x800'); root.minsize(850,600); root.configure(bg='#141519')
try:root.iconbitmap(str(BASE/'GTA VI.ico'))
except (OSError,tk.TclError):pass
def apply_taskbar_icon():
 try:
  user=ctypes.windll.user32
  user.GetParent.argtypes=[ctypes.c_void_p]; user.GetParent.restype=ctypes.c_void_p
  user.LoadImageW.argtypes=[ctypes.c_void_p,ctypes.c_wchar_p,ctypes.c_uint,ctypes.c_int,ctypes.c_int,ctypes.c_uint]; user.LoadImageW.restype=ctypes.c_void_p
  user.SendMessageW.argtypes=[ctypes.c_void_p,ctypes.c_uint,ctypes.c_size_t,ctypes.c_void_p]; user.SendMessageW.restype=ctypes.c_ssize_t
  user.GetAncestor.argtypes=[ctypes.c_void_p,ctypes.c_uint]; user.GetAncestor.restype=ctypes.c_void_p
  hwnd=user.GetAncestor(root.winfo_id(),2) or root.winfo_id()
  for kind,size in ((0,32),(1,256),(2,32)):
   ico=user.LoadImageW(None,str(BASE/'GTA VI.ico'),1,size,size,0x10)
   if ico:user.SendMessageW(hwnd,0x80,kind,ico)
 except Exception:pass
# Tk sets its own window icons without cross-process messaging.
try:
 icon_image=ImageTk.PhotoImage(Image.open(BASE/'GTA VI.ico').convert('RGBA'))
 root.iconphoto(True,icon_image)
except Exception:pass

try:
 from window_branding import apply_branding
 root.after_idle(lambda:apply_branding(root,BASE/'GTA VI.ico'))
except ImportError:pass
mode=tk.StringVar(value='Windowed'); status=tk.StringVar(); proc=None


def save():
 cfg.pop("mouse_sensitivity",None); cfg['mode']=mode.get(); CFG.parent.mkdir(parents=True,exist_ok=True); CFG.write_text(json.dumps(cfg,indent=2))
def data_root():
 return BASE
from install_manager import ready, register, shortcut, FILES
def installed():
 return ready(data_root())
def refresh():
 if not installed():
  status.set('INSTALLATION INCOMPLETE');return
 status.set('READY TO PLAY' if Path(cfg.get('exe','')).is_file() else 'SETUP REQUIRED')
def choose():
 p=filedialog.askopenfilename(title='Select original AstraPlay GTA VI shortcut or executable',filetypes=[('Windows applications and shortcuts','*.exe *.lnk'),('All files','*.*')]); args=''; shortcut=p if p.lower().endswith('.lnk') else ''
 if not p:return False
 if p.lower().endswith('.lnk'):
  try:
   command="$s=(New-Object -ComObject WScript.Shell).CreateShortcut($env:GTAVI_SHORTCUT); @{exe=$s.TargetPath;args=$s.Arguments}|ConvertTo-Json -Compress"
   data=json.loads(subprocess.check_output(['powershell.exe','-NoProfile','-Command',command],env=dict(os.environ,GTAVI_SHORTCUT=p),creationflags=0x08000000,timeout=10).decode('utf-8-sig')); p=data['exe']; args=data.get('args','')
  except Exception as e: messagebox.showerror('Shortcut error',str(e)); return False
 if not Path(p).is_file(): messagebox.showerror('Setup','Executable not found'); return False
 args=simpledialog.askstring('Launch arguments','Keep the original shortcut arguments, if available:',initialvalue=args,parent=root)
 if args is None:return False
 cfg.update(exe=p,args=args,shortcut=shortcut); save(); refresh(); return True

# Local audio only; no downloads or external player required.
music_enabled=tk.BooleanVar(value=True)
music_volume=tk.IntVar(value=max(0,min(100,int(cfg.get('music_volume',55)))))
music_status=tk.StringVar(value='No music selected')
audio_queue=queue.Queue()
def audio_worker():
 mci=ctypes.windll.winmm.mciSendStringW
 mci.argtypes=[ctypes.c_wchar_p,ctypes.c_wchar_p,ctypes.c_uint,ctypes.c_void_p];mci.restype=ctypes.c_uint
 def cmd(s):return mci(s,None,0,None)
 opened=False
 while True:
  action=audio_queue.get()
  if action=='quit':
   if opened:cmd('close gtavimusic')
   return
  if action=='pause' and opened:cmd('pause gtavimusic')
  if action=='play':
   if not opened:
    opened=not cmd('open "'+str(BASE/'Launcher Music.mp3')+'" type mpegvideo alias gtavimusic')
    if opened:cmd('setaudio gtavimusic volume to 550');cmd('play gtavimusic repeat')
   elif cmd('resume gtavimusic'):cmd('play gtavimusic repeat')
threading.Thread(target=audio_worker,daemon=True).start()
def stop_music():audio_queue.put('pause')
def start_music():
 if (BASE/'Launcher Music.mp3').is_file():audio_queue.put('play')
def close_launcher():
 audio_queue.put("quit");rpc.close();root.destroy()
root.protocol('WM_DELETE_WINDOW',close_launcher)

from presence import Presence
rpc=Presence(cfg.get("discord_id", ""))
rpc.set(False)
def configure_discord():
 global rpc
 value=simpledialog.askstring('Discord connection','Enter the public Application ID from Discord Developer Portal (not your account ID).',initialvalue=cfg.get('discord_id',''),parent=root)
 if value is None:return
 if not value.strip().isdigit():messagebox.showerror('Discord','Enter a numeric application ID.');return
 cfg['discord_id']=value.strip();save();rpc.close();rpc=Presence(value);rpc.set(bool(proc and proc.poll() is None))
session_file=None
def manage():
 if not installed():return
 os.startfile(str(data_root()))
def download_components():
 messagebox.showerror('Installation incomplete','Run the setup again to restore missing launcher files.',parent=root)
def play():
 global proc,session_file
 if not installed():download_components();return
 if proc and proc.poll() is None:return
 if not Path(cfg.get('exe','')).is_file() and not choose():return
 save()
 stop_music()
 session_file=CFG.parent/("session-"+uuid.uuid4().hex+".txt")
 try: proc=subprocess.Popen([sys.executable,str(data_root()/'player.pyw')]+(['--'+mode.get().lower(),str(session_file)]),cwd=str(BASE))
 except OSError as e:start_music();messagebox.showerror('Launch failed',str(e));return
 rpc.set(True); playbtn.config(state='disabled',text='CONNECTING…'); status.set('WAITING FOR GAME WINDOW'); root.after(150,watch)
def watch():
 if proc.poll() is None:
  if session_file and session_file.exists() :
   playbtn.config(text='RUNNING');status.set('IN GAME')
   if not rpc.game:rpc.set(True)
  root.after(200,watch);return
 if session_file:session_file.unlink(missing_ok=True)
 playbtn.config(state='normal',text='PLAY  ▶');refresh();start_music();rpc.set(False)
BG='#15131e'; PANEL='#201d2a'; MUTED='#aaa4b6'; PINK='#ff8bb9'
def label(parent,text,size=11,fg='white',bg=PANEL,bold=False):
 return tk.Label(parent,text=text,font=('Segoe UI',size,'bold' if bold else 'normal'),fg=fg,bg=bg,anchor='w')
def button(parent,text,cmd,bg='#353040',fg='white'):
 return tk.Button(parent,text=text,command=cmd,bg=bg,fg=fg,activebackground='#53435c',activeforeground='white',relief='flat',bd=0,padx=16,pady=11,font=('Segoe UI',11,'bold'),cursor='hand2')
def settings():
 overlay.lift(); overlay.place(relx=0,rely=0,relwidth=1,relheight=1); overlay.lift(); pathvar.set(cfg.get('exe','Not configured'))
def library():
 overlay.place_forget(); playbtn.focus_set()
side=tk.Frame(root,bg=PANEL,width=245);side.pack(side='left',fill='y');side.pack_propagate(False)
label(side,'Grand Theft Auto',19,bold=True).pack(anchor='w',padx=20,pady=(30,0))
label(side,'VI  /  GAME LAUNCHER',12,PINK,bold=True).pack(anchor='w',padx=20,pady=(3,38))
label(side,'MY LIBRARY',10,MUTED,bold=True).pack(anchor='w',padx=20)
entry=tk.Frame(side,bg='#393042');entry.pack(fill='x',padx=10,pady=12)
tk.Frame(entry,bg=PINK,width=4).pack(side='left',fill='y')
libbtn=button(entry,'Grand Theft Auto VI',library,'#393042');libbtn.pack(fill='x',expand=True)
label(side,'1 GAME  •  PC EDITION',9,MUTED).pack(anchor='w',padx=20)
settingsbtn=button(side,'Settings',settings);settingsbtn.pack(side='bottom',fill='x',padx=14,pady=18)
controller=tk.StringVar(value='Keyboard & Mouse — Direct Input')
discord_status=tk.StringVar(value='Discord: checking…')
tk.Label(side,textvariable=discord_status,bg=PANEL,fg=MUTED,wraplength=210).pack(side='bottom',pady=5)
tk.Label(side,textvariable=controller,wraplength=210,bg=PANEL,fg=PINK,font=('Segoe UI',10)).pack(side='bottom',padx=12,pady=10)
main=tk.Frame(root,bg=BG);main.pack(side='left',fill='both',expand=True)
canvas=tk.Canvas(main,bg=BG,highlightthickness=0);canvas.pack(fill='both',expand=True)
art=None;photo=None;pending=None
render_queue=queue.Queue(maxsize=1); render_results=queue.Queue(maxsize=1)
render_id=0
def render_worker():
 while True:
  seq,w,h=render_queue.get()
  try:
   im=ImageOps.fit(art,(w,h),Image.Resampling.BILINEAR); shade=Image.new("RGBA",(w,h));d=ImageDraw.Draw(shade)
   for y in range(h):
    t=y/h; alpha=int(35+205*max(0,(t-.40)/.60)**1.3);d.line((0,y,w,y),fill=(15,10,25,alpha))
   result=(seq,Image.alpha_composite(im.convert("RGBA"),shade))
   try:render_results.get_nowait()
   except queue.Empty:pass
   render_results.put_nowait(result)
  except Exception:pass
def receive_render():
 global photo
 try:
  seq,im=render_results.get_nowait()
  if seq==render_id:
   photo=ImageTk.PhotoImage(im);canvas.itemconfigure(bgitem,image=photo)
 except queue.Empty:pass
 root.after(50,receive_render)
def load_art():
 global art
 try:art=Image.open(BASE/'launcher_assets.dat').convert('RGB')
 except (OSError,ValueError):art=Image.new('RGB',(1280,800),'#21182b')
def redraw():
 global pending,render_id
 pending=None;w=max(1,canvas.winfo_width());h=max(1,canvas.winfo_height())
 if w<20 or h<20:return
 render_id+=1
 try:render_queue.get_nowait()
 except queue.Empty:pass
 render_queue.put_nowait((render_id,w,h))
 canvas.coords(eyebrow,34,h-220);canvas.coords(titleitem,34,h-185);canvas.coords(descitem,36,h-125);canvas.coords(playitem,34,h-88);canvas.coords(statusitem,260,h-60)
 canvas.coords(footitem,36,h-16)
def resize(e):
 global pending
 if pending:root.after_cancel(pending)
 pending=root.after(150,redraw)
bgitem=canvas.create_image(0,0,anchor='nw')
eyebrow=canvas.create_text(34,0,text='DEV VERSION  /  PC BUILD',fill='#ffb0c9',font=('Segoe UI',11,'bold'),anchor='nw')
titleitem=canvas.create_text(34,0,text='Grand Theft Auto VI',fill='white',font=('Segoe UI',30,'bold'),anchor='nw')
descitem=canvas.create_text(36,0,text='Welcome to Vice City. Native-style PC gameplay.',fill='#eee4ef',font=('Segoe UI',12),anchor='nw')
playbtn=button(canvas,'PLAY  ▶' if installed() else 'REPAIR REQUIRED',play,'#ff8bb9','#241323');playbtn.configure(font=('Segoe UI',17,'bold'),width=13)
playitem=canvas.create_window(34,0,window=playbtn,anchor='nw')
statusrow=tk.Frame(canvas,bg='#21182b')
statuslabel=tk.Label(statusrow,textvariable=status,bg='#21182b',fg='white',padx=10,pady=5,wraplength=200);statuslabel.pack(side='left')
managebtn=button(statusrow,"Manage installation",manage);managebtn.config(state="normal" if installed() else "disabled");managebtn.pack(side='left',padx=(8,0))
statusitem=canvas.create_window(260,0,window=statusrow,anchor='w')
footitem=canvas.create_text(36,0,text='DEV VERSION  •  PC BUILD',fill='#bcb0c7',font=('Segoe UI',9),anchor='sw')
load_art();threading.Thread(target=render_worker,daemon=True).start();root.after(50,receive_render);canvas.bind('<Configure>',resize)
overlay=tk.Frame(main,bg=BG);pathvar=tk.StringVar()
header=tk.Frame(overlay,bg=BG);header.pack(fill='x',padx=34,pady=(30,20));label(header,'Settings',28,bg=BG,bold=True).pack(side='left');backbtn=button(header,'Back to library',library);backbtn.pack(side='right'); setting_controls=[backbtn]
for heading,subtitle in [('DISPLAY','Choose how the game window opens.'),('GAME LOCATION','Your saved Remote Play application or shortcut.')]:
 section=tk.Frame(overlay,bg=PANEL);section.pack(fill='x',padx=34,pady=8)
 label(section,heading,12,PINK,bold=True).pack(anchor='w',padx=18,pady=(12,0));label(section,subtitle,10,MUTED).pack(anchor='w',padx=18,pady=(3,8))
 row=tk.Frame(section,bg=PANEL);row.pack(fill='x',padx=18,pady=(0,12))
 if heading=='DISPLAY':
  for v in ('Windowed','Maximized','Fullscreen'):
   rb=tk.Radiobutton(row,text=v,variable=mode,value=v,bg=PANEL,fg='white',selectcolor='#42364d',activebackground=PANEL,activeforeground='white',command=save,font=('Segoe UI',11));rb.pack(side='left',padx=(0,24));setting_controls.append(rb)
 elif heading=='GAME LOCATION':
  browsebtn=button(row,'Browse…',lambda:(choose(),pathvar.set(cfg.get('exe','Not configured'))));browsebtn.pack(side='right');setting_controls.append(browsebtn);tk.Label(row,textvariable=pathvar,bg=PANEL,fg='white',wraplength=420,justify='left').pack(side='left',fill='x',expand=True)
discordbtn=button(overlay,'Connect Discord',configure_discord);discordbtn.pack(anchor='w',padx=34,pady=4);setting_controls.append(discordbtn)
label(overlay,'Changes are saved automatically and apply on the next launch.',10,MUTED,BG).pack(anchor='w',padx=34,pady=12)
class Pad(ctypes.Structure):
 _fields_=[('buttons',wintypes.WORD),('lt',ctypes.c_ubyte),('rt',ctypes.c_ubyte),('lx',ctypes.c_short),('ly',ctypes.c_short),('rx',ctypes.c_short),('ry',ctypes.c_short)]
class State(ctypes.Structure):
 _fields_=[('packet',wintypes.DWORD),('pad',Pad)]
class Joy(ctypes.Structure):
 _fields_=[(x,wintypes.DWORD) for x in ('size','flags','x','y','z','r','u','v','buttons','button','pov','reserved1','reserved2')]
xinput=None
for dll in ('xinput1_4','xinput1_3','xinput9_1_0'):
 try:xinput=ctypes.WinDLL(dll);break
 except OSError:pass
class Caps(ctypes.Structure):
 _fields_=[('mid',wintypes.WORD),('pid',wintypes.WORD),('name',ctypes.c_wchar*32),('rest',ctypes.c_byte*1024)]
pad_queue=queue.Queue(maxsize=1)
def pad_worker():
 mm=ctypes.windll.winmm
 while True:
  names=[]; keys=set(); xconnected=False; active=False; game=proc is not None and proc.poll() is None
  try:
   if xinput and not game:
    for i in range(4):
     st=State()
     if xinput.XInputGetState(i,ctypes.byref(st))==0:
      xconnected=True;b=st.pad.buttons
      active=active or bool(b or st.pad.lt>35 or st.pad.rt>35 or max(abs(st.pad.lx),abs(st.pad.ly),abs(st.pad.rx),abs(st.pad.ry))>12000)
      if b&0x1000:keys.add('ok')
      if b&0x2000:keys.add('back')
      if b&5 or st.pad.ly>16000 or st.pad.lx<-16000:keys.add('prev')
      if b&10 or st.pad.ly<-16000 or st.pad.lx>16000:keys.add('next')
   for i in range(min(mm.joyGetNumDevs(),16)):
    j=Joy();j.size=ctypes.sizeof(j);j.flags=0xff
    if mm.joyGetPosEx(i,ctypes.byref(j))!=0:continue
    cap=Caps();name='DirectInput controller'
    if mm.joyGetDevCapsW(ctypes.c_size_t(i),ctypes.byref(cap),ctypes.sizeof(cap))==0:name=cap.name or name
    if game and any(t in name.lower() for t in ('xbox 360','xbox 360','vigem','virtual','xinput')):continue
    names.append(name)
    active=active or bool(j.buttons or j.pov!=65535 or abs(int(j.x)-32767)>12000 or abs(int(j.y)-32767)>12000)
    if not xconnected:
     if j.buttons&3:keys.add('ok')
     if j.buttons&4:keys.add('back')
     if j.pov in (0,27000) or j.x<16000 or j.y<16000:keys.add('prev')
     if j.pov in (9000,18000) or j.x>49000 or j.y>49000:keys.add('next')
  except Exception:pass
  if xconnected and not names:names=['Xbox / XInput controller']
  try:pad_queue.get_nowait()
  except queue.Empty:pass
  try:pad_queue.put_nowait((names,keys,active))
  except queue.Full:pass
  time.sleep(.08)
threading.Thread(target=pad_worker,daemon=True).start()
last=set(); selected=None; painted_selection=None; lastmove=0; input_kind="keyboard"; last_mouse=None; last_activity=0
def poll_controller():
 global last,selected,lastmove,input_kind,last_mouse,last_activity,painted_selection
 try:names,keys,active=pad_queue.get_nowait()
 except queue.Empty:root.after(150,poll_controller);return
 game=proc is not None and proc.poll() is None
 point=wintypes.POINT();ctypes.windll.user32.GetCursorPos(ctypes.byref(point));pos=(point.x,point.y)
 keyboard=any(ctypes.windll.user32.GetAsyncKeyState(k)&0x8000 for k in (1,2,13,32,65,68,83,87,16,17,27))
 if not game and last_mouse is not None and pos!=last_mouse:keyboard=True
 last_mouse=pos
 if active and names:input_kind='controller'
 elif keyboard or not names:input_kind='keyboard'
 new_status='Controller Connected\n'+' / '.join(dict.fromkeys(names)) if input_kind=='controller' else 'Keyboard & Mouse — Direct Input'
 if discord_status.get()!='Discord: '+rpc.status:discord_status.set('Discord: '+rpc.status)
 if controller.get()!=new_status:controller.set(new_status)
 if input_kind=='controller' and names and root.focus_displayof() is not None and (proc is None or proc.poll() is not None):
  controls=setting_controls if overlay.winfo_ismapped() else [playbtn,libbtn,settingsbtn]
  if selected not in controls:selected=controls[0]
  now=time.monotonic(); direction=keys & {'prev','next'}
  if direction and (direction-last or now-lastmove>.35):
   selected=controls[(controls.index(selected)+(1 if 'next' in direction else -1))%len(controls)];lastmove=now
  if painted_selection is not selected:
   for widget in [playbtn,libbtn,settingsbtn]+setting_controls:
    widget.configure(highlightthickness=2,highlightbackground=PINK if widget is selected else BG,highlightcolor=PINK)
   painted_selection=selected
  if 'back' in keys-last:library();selected=playbtn
  elif 'ok' in keys-last:selected.invoke()
 last=keys;root.after(150,poll_controller)
playbtn.focus_set();root.after(100,poll_controller)
refresh()
if '--setup' in sys.argv:root.after(100,choose)
root.after(250,start_music)
from update_manager_v2 import startup
root.after(350,lambda: startup(root,playbtn,status))
root.mainloop()
